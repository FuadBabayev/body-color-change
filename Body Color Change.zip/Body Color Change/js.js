let zaman = setInterval(A,1000);
let time = 0;
function A(){
let body = document.body; 
let color= "";   
color = (time)%2==0 ? "yellow" : "blue";
body.style.bgColor = color;
body.innerHTML = time + " " + color;
time++;
}

function stop(){
clearInterval(zaman);
}